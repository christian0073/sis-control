$(document).ready(function(){
	$('.select2').select2();
   	activarLinkMenu("cambios", "#registrar");
});