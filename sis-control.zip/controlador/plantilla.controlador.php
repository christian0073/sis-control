<?php 
	Class ControladorPlantilla{
		public function ctrPlantilla(){
			include "vistas/plantilla.php";
		}
	}
 ?>