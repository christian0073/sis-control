<?php 
	Class ControladorRuta{
		static public function ctrRuta(){
			return "http://localhost/sis-control/";
		}
	}
 ?>